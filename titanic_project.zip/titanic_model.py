import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Sample data (as we can't use full train.csv on mobile)
data = {
    'Pclass': [3, 1, 3, 1],
    'Sex': ['male', 'female', 'female', 'male'],
    'Age': [22, 38, 26, 35],
    'SibSp': [1, 1, 0, 1],
    'Parch': [0, 0, 0, 0],
    'Survived': [0, 1, 1, 1]
}

df = pd.DataFrame(data)
df["Sex"] = df["Sex"].map({"male": 0, "female": 1})

X = df[["Pclass", "Sex", "Age", "SibSp", "Parch"]]
y = df["Survived"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)

model = RandomForestClassifier()
model.fit(X_train, y_train)

predictions = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, predictions))